
import { supabase } from '@/integrations/supabase/client';
import { Restaurant, MenuItem, User, Order, OrderItem, Payment } from '@/types';

export const restaurantService = {
  // Get all restaurants
  getAllRestaurants: async (): Promise<Restaurant[]> => {
    const { data, error } = await supabase
      .from('restaurants')
      .select('*');
    
    if (error) {
      console.error('Error fetching restaurants:', error);
      throw error;
    }
    
    return data as Restaurant[];
  },
  
  // Get restaurants by cuisine type
  getRestaurantsByCuisine: async (cuisine: string): Promise<Restaurant[]> => {
    const { data, error } = await supabase
      .from('restaurants')
      .select('*')
      .ilike('cuisine_type', `%${cuisine}%`);
    
    if (error) {
      console.error('Error fetching restaurants by cuisine:', error);
      throw error;
    }
    
    return data as Restaurant[];
  },
  
  // Get a single restaurant by ID
  getRestaurantById: async (id: string): Promise<Restaurant> => {
    const { data, error } = await supabase
      .from('restaurants')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error('Error fetching restaurant:', error);
      throw error;
    }
    
    return data as Restaurant;
  }
};

export const menuService = {
  // Get menu items for a specific restaurant
  getMenuItems: async (restaurantId: string): Promise<MenuItem[]> => {
    const { data, error } = await supabase
      .from('menu_items')
      .select('*')
      .eq('restaurant_id', restaurantId);
    
    if (error) {
      console.error('Error fetching menu items:', error);
      throw error;
    }
    
    return data as MenuItem[];
  },
  
  // Get menu item by ID
  getMenuItemById: async (id: string): Promise<MenuItem> => {
    const { data, error } = await supabase
      .from('menu_items')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error('Error fetching menu item:', error);
      throw error;
    }
    
    return data as MenuItem;
  },
  
  // Get menu items by category
  getMenuItemsByCategory: async (restaurantId: string, category: string): Promise<MenuItem[]> => {
    const { data, error } = await supabase
      .from('menu_items')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .eq('category', category);
    
    if (error) {
      console.error('Error fetching menu items by category:', error);
      throw error;
    }
    
    return data as MenuItem[];
  }
};

export const userService = {
  // Get user profile
  getUserProfile: async (userId: string): Promise<User> => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error) {
      console.error('Error fetching user profile:', error);
      throw error;
    }
    
    return data as User;
  },
  
  // Update user profile
  updateUserProfile: async (userId: string, userData: Partial<User>): Promise<User> => {
    const { data, error } = await supabase
      .from('users')
      .update(userData)
      .eq('id', userId)
      .select()
      .single();
    
    if (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
    
    return data as User;
  }
};

export const orderService = {
  // Create a new order
  createOrder: async (orderData: Omit<Order, 'id' | 'created_at'>, orderItems: Omit<OrderItem, 'id' | 'created_at' | 'order_id'>[]): Promise<{ order: Order, orderItems: OrderItem[] }> => {
    // Start a Supabase transaction by using a callback
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert(orderData)
      .select()
      .single();
    
    if (orderError) {
      console.error('Error creating order:', orderError);
      throw orderError;
    }
    
    // Add the order_id to each order item
    const orderItemsWithOrderId = orderItems.map(item => ({
      ...item,
      order_id: order.id
    }));
    
    // Insert all order items
    const { data: createdOrderItems, error: orderItemsError } = await supabase
      .from('order_items')
      .insert(orderItemsWithOrderId)
      .select();
    
    if (orderItemsError) {
      console.error('Error creating order items:', orderItemsError);
      throw orderItemsError;
    }
    
    return { 
      order: order as Order, 
      orderItems: createdOrderItems as OrderItem[] 
    };
  },
  
  // Get orders for a user
  getUserOrders: async (userId: string): Promise<Order[]> => {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', userId)
      .order('order_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching user orders:', error);
      throw error;
    }
    
    return data as Order[];
  },
  
  // Get order details including items
  getOrderDetails: async (orderId: string): Promise<{ order: Order; items: OrderItem[] }> => {
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single();
    
    if (orderError) {
      console.error('Error fetching order:', orderError);
      throw orderError;
    }
    
    const { data: items, error: itemsError } = await supabase
      .from('order_items')
      .select(`
        *,
        item:item_id (*)
      `)
      .eq('order_id', orderId);
    
    if (itemsError) {
      console.error('Error fetching order items:', itemsError);
      throw itemsError;
    }
    
    return { 
      order: order as Order, 
      items: items as OrderItem[] 
    };
  },
  
  // Update order status
  updateOrderStatus: async (orderId: string, status: string): Promise<Order> => {
    const { data, error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId)
      .select()
      .single();
    
    if (error) {
      console.error('Error updating order status:', error);
      throw error;
    }
    
    return data as Order;
  }
};

export const paymentService = {
  // Create a payment record
  createPayment: async (paymentData: Omit<Payment, 'id' | 'created_at'>): Promise<Payment> => {
    const { data, error } = await supabase
      .from('payments')
      .insert(paymentData)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating payment:', error);
      throw error;
    }
    
    return data as Payment;
  },
  
  // Get payment details for an order
  getPaymentByOrderId: async (orderId: string): Promise<Payment> => {
    const { data, error } = await supabase
      .from('payments')
      .select('*')
      .eq('order_id', orderId)
      .single();
    
    if (error) {
      console.error('Error fetching payment:', error);
      throw error;
    }
    
    return data as Payment;
  }
};
