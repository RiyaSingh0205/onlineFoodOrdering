
export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  created_at?: string;
}

export interface Restaurant {
  id: string;
  name: string;
  address: string;
  rating: number;
  image_url: string;
  cuisine_type: string;
  delivery_time?: string;
  min_order?: number;
}

export interface MenuItem {
  id: string;
  restaurant_id: string;
  name: string;
  price: number;
  category: string;
  description?: string;
  image_url?: string;
}

export interface Category {
  id: string;
  name: string;
  restaurant_id?: string;
}

export interface Order {
  id: string;
  restaurant_id: string;
  user_id: string;
  order_date: string;
  status: string; // Changed from enum to string to match database schema
  delivery_address?: string;
  special_instructions?: string;
  total_amount: number;
}

export interface OrderItem {
  id: string;
  order_id: string;
  item_id: string;
  quantity: number;
  total: number;
}

export interface Payment {
  id: string;
  order_id: string;
  method: string; // Changed from enum to string to match database schema
  amount: number;
  status: string; // Changed from enum to string to match database schema
  transaction_id?: string;
  payment_date?: string;
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
  total: number;
}

export interface Cart {
  items: CartItem[];
  restaurant_id: string | null;
  total: number;
}
