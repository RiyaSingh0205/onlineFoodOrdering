import { Restaurant, MenuItem, User, Order } from "@/types";

export const sampleRestaurants: Restaurant[] = [
  {
    id: "1",
    name: "Taj Mahal Restaurant",
    address: "123 MG Road, Bangalore, Karnataka",
    rating: 4.5,
    image_url: "https://img.freepik.com/free-photo/chicken-skewers-with-slices-sweet-peppers-dill_2829-18813.jpg?size=626&ext=jpg",
    cuisine_type: "North Indian",
    delivery_time: "30-40 min",
    min_order: 200
  },
  {
    id: "2",
    name: "Dosa World",
    address: "456 Indiranagar, Bangalore, Karnataka",
    rating: 4.2,
    image_url: "https://img.freepik.com/free-photo/top-view-indian-food-assortment_23-2148747713.jpg?size=626&ext=jpg",
    cuisine_type: "South Indian",
    delivery_time: "25-35 min",
    min_order: 150
  },
  {
    id: "3",
    name: "Spice Garden",
    address: "789 Koramangala, Bangalore, Karnataka",
    rating: 4.8,
    image_url: "https://img.freepik.com/free-photo/indian-butter-chicken-with-rice-homemade-indian-food_123827-20757.jpg?size=626&ext=jpg",
    cuisine_type: "North Indian",
    delivery_time: "35-45 min",
    min_order: 250
  },
  {
    id: "4",
    name: "Chinese Wok",
    address: "101 Brigade Road, Bangalore, Karnataka",
    rating: 4.0,
    image_url: "https://img.freepik.com/free-photo/top-view-mix-chinese-food_23-2148746353.jpg?size=626&ext=jpg",
    cuisine_type: "Chinese",
    delivery_time: "25-35 min",
    min_order: 180
  },
  {
    id: "5",
    name: "Punjab House",
    address: "222 Whitefield, Bangalore, Karnataka",
    rating: 4.6,
    image_url: "https://img.freepik.com/free-photo/side-view-club-sandwich-with-salted-cucumbers-lemon-olives-round-white-plate_176474-3034.jpg?size=626&ext=jpg",
    cuisine_type: "North Indian",
    delivery_time: "30-40 min",
    min_order: 300
  },
  {
    id: "6",
    name: "Bangalore Street Food",
    address: "333 Jayanagar, Bangalore, Karnataka",
    rating: 4.3,
    image_url: "https://img.freepik.com/free-photo/pani-puri-also-known-golgappa-chat-item-fuchka_466689-76835.jpg?size=626&ext=jpg",
    cuisine_type: "Street Food",
    delivery_time: "20-30 min",
    min_order: 120
  },
  {
    id: "7",
    name: "Biryani House",
    address: "444 HSR Layout, Bangalore, Karnataka",
    rating: 4.7,
    image_url: "https://img.freepik.com/free-photo/traditional-indian-soup-lentils-indian-dhal-spicy-curry-bowl-spices-herbs-rustic-black-wooden-table_2829-18717.jpg?size=626&ext=jpg",
    cuisine_type: "Biryani",
    delivery_time: "35-45 min",
    min_order: 280
  },
  {
    id: "8",
    name: "Sweet Memories",
    address: "555 JP Nagar, Bangalore, Karnataka",
    rating: 4.4,
    image_url: "https://img.freepik.com/free-photo/gulab-jamun-sweet-food-dessert_96696-323.jpg?size=626&ext=jpg",
    cuisine_type: "Sweets",
    delivery_time: "25-35 min",
    min_order: 150
  }
];

export const sampleMenuItems: MenuItem[] = [
  // Restaurant 1 - Taj Mahal Restaurant
  {
    id: "101",
    restaurant_id: "1",
    name: "Butter Chicken",
    price: 350,
    category: "Main Course",
    description: "Tender chicken cooked in rich tomato and butter gravy",
    image_url: "https://img.freepik.com/free-photo/authentic-indian-food-arrangement_23-2148747691.jpg?size=626&ext=jpg"
  },
  {
    id: "102",
    restaurant_id: "1",
    name: "Naan",
    price: 60,
    category: "Bread",
    description: "Traditional Indian bread baked in tandoor",
    image_url: "https://img.freepik.com/free-photo/naan-flatbread_1339-1402.jpg?size=626&ext=jpg"
  },
  {
    id: "103",
    restaurant_id: "1",
    name: "Paneer Tikka",
    price: 280,
    category: "Starters",
    description: "Marinated cottage cheese cubes grilled to perfection",
    image_url: "https://img.freepik.com/free-photo/indian-tasty-food-arrangement_23-2148747713.jpg?size=626&ext=jpg"
  },
  {
    id: "104",
    restaurant_id: "1",
    name: "Dal Makhani",
    price: 220,
    category: "Main Course",
    description: "Black lentils cooked overnight with butter and cream",
    image_url: "https://img.freepik.com/free-photo/delicious-indian-food-arrangement_23-2148749636.jpg?size=626&ext=jpg"
  },
  
  // Restaurant 2 - Dosa World
  {
    id: "201",
    restaurant_id: "2",
    name: "Masala Dosa",
    price: 150,
    category: "Main Course",
    description: "Crispy rice crepe filled with spiced potato filling",
    image_url: "https://img.freepik.com/free-photo/dosa-also-called-dosai-dosey-indian-food_57665-7355.jpg?size=626&ext=jpg"
  },
  {
    id: "202",
    restaurant_id: "2",
    name: "Idli Sambar",
    price: 120,
    category: "Breakfast",
    description: "Steamed rice cakes served with lentil soup",
    image_url: "https://img.freepik.com/free-photo/idli-vada-sambar-with-coconut-chutney-idly-rice-cake-indian-main-popular-breakfast-item-which-beautifully-arranged-plate-bowl-with-banana-leaf_466689-9743.jpg?size=626&ext=jpg"
  },
  {
    id: "203",
    restaurant_id: "2",
    name: "Vada",
    price: 80,
    category: "Breakfast",
    description: "Deep-fried savory doughnut served with coconut chutney",
    image_url: "https://img.freepik.com/free-photo/vada-medu-vada-vadai-are-south-indian-breakfast-snack-white-background_466689-72313.jpg?size=626&ext=jpg"
  },
  {
    id: "204",
    restaurant_id: "2",
    name: "Mysore Pak",
    price: 100,
    category: "Dessert",
    description: "Traditional South Indian sweet made from gram flour, ghee and sugar",
    image_url: "https://img.freepik.com/free-photo/high-angle-sweet-honey-slices_23-2148493718.jpg?size=626&ext=jpg"
  },
  
  // Restaurant 3 - Spice Garden
  {
    id: "301",
    restaurant_id: "3",
    name: "Chicken Biryani",
    price: 320,
    category: "Main Course",
    description: "Fragrant basmati rice cooked with tender chicken and spices",
    image_url: "https://img.freepik.com/free-photo/traditional-indian-cuisine-with-spices_23-2148747661.jpg?size=626&ext=jpg"
  },
  {
    id: "302",
    restaurant_id: "3",
    name: "Tandoori Roti",
    price: 40,
    category: "Bread",
    description: "Whole wheat bread baked in clay oven",
    image_url: "https://img.freepik.com/free-photo/close-up-tasty-pita-bread_23-2148294542.jpg?size=626&ext=jpg"
  },
  {
    id: "303",
    restaurant_id: "3",
    name: "Malai Kofta",
    price: 280,
    category: "Main Course",
    description: "Fried vegetable dumplings in rich creamy gravy",
    image_url: "https://img.freepik.com/free-photo/tasty-food-arrangement_23-2148931502.jpg?size=626&ext=jpg"
  },
  
  // Restaurant 4 - Chinese Wok
  {
    id: "401",
    restaurant_id: "4",
    name: "Veg Fried Rice",
    price: 180,
    category: "Main Course",
    description: "Stir-fried rice with mixed vegetables and soy sauce",
    image_url: "https://img.freepik.com/free-photo/fried-rice-with-vegetables_1339-2367.jpg?size=626&ext=jpg"
  },
  {
    id: "402",
    restaurant_id: "4",
    name: "Hakka Noodles",
    price: 190,
    category: "Main Course",
    description: "Stir-fried noodles with vegetables and spices",
    image_url: "https://img.freepik.com/free-photo/noodles-with-vegetables-meat-chicken-prawn-sweet-sour-sauce-plate_140725-10308.jpg?size=626&ext=jpg"
  },
  {
    id: "403",
    restaurant_id: "4",
    name: "Manchurian",
    price: 210,
    category: "Starters",
    description: "Deep-fried vegetable balls in a spicy, sweet and sour sauce",
    image_url: "https://img.freepik.com/free-photo/deep-fried-meatballs-served-with-spicy-sauce-wooden-cutting-board-with-herbs_114579-1888.jpg?size=626&ext=jpg"
  },
  {
    id: "404",
    restaurant_id: "4",
    name: "Spring Rolls",
    price: 160,
    category: "Starters",
    description: "Crispy rolls filled with vegetables and served with dipping sauce",
    image_url: "https://img.freepik.com/free-photo/fresh-spring-rolls-with-vegetables-sauce-black-plate_1150-21500.jpg?size=626&ext=jpg"
  },
  
  // Restaurant 5 - Punjab House
  {
    id: "501",
    restaurant_id: "5",
    name: "Chole Bhature",
    price: 180,
    category: "Main Course",
    description: "Spiced chickpea curry served with deep-fried bread",
    image_url: "https://img.freepik.com/free-photo/indian-food-arrangement-with-copy-space_23-2148747638.jpg?size=626&ext=jpg"
  },
  {
    id: "502",
    restaurant_id: "5",
    name: "Sarson Da Saag",
    price: 220,
    category: "Main Course",
    description: "Traditional Punjabi dish made from mustard greens, served with makki di roti",
    image_url: "https://img.freepik.com/free-photo/top-view-delicious-food-bowl_23-2148746312.jpg?size=626&ext=jpg"
  },
  {
    id: "503",
    restaurant_id: "5",
    name: "Amritsari Fish",
    price: 340,
    category: "Starters",
    description: "Crispy fried fish fillets coated with spiced gram flour batter",
    image_url: "https://img.freepik.com/free-photo/fried-fish-carp-fresh-vegetable-salad-wooden-table_2829-19928.jpg?size=626&ext=jpg"
  },
  {
    id: "504",
    restaurant_id: "5",
    name: "Butter Chicken",
    price: 320,
    category: "Main Course",
    description: "Classic Punjabi dish with chicken in creamy tomato gravy",
    image_url: "https://img.freepik.com/free-photo/chicken-curry-black-bowl-with-rice_1150-24337.jpg?size=626&ext=jpg"
  },
  
  // Restaurant 6 - Bangalore Street Food
  {
    id: "601",
    restaurant_id: "6",
    name: "Pani Puri",
    price: 60,
    category: "Chat",
    description: "Hollow crisp fried balls filled with spicy tangy water, potato, and chickpeas",
    image_url: "https://img.freepik.com/free-photo/pani-puri-also-known-golgappa-chat-item-fuchka_466689-76835.jpg?size=626&ext=jpg"
  },
  {
    id: "602",
    restaurant_id: "6",
    name: "Bhel Puri",
    price: 70,
    category: "Chat",
    description: "Puffed rice, vegetables and a tangy tamarind sauce",
    image_url: "https://img.freepik.com/free-photo/delicious-indian-food-tray_23-2148723505.jpg?size=626&ext=jpg"
  },
  {
    id: "603",
    restaurant_id: "6",
    name: "Masala Dahi Puri",
    price: 80,
    category: "Chat",
    description: "Crispy puris topped with yogurt, chutneys, and sev",
    image_url: "https://img.freepik.com/free-photo/indian-chaat-food_57665-13243.jpg?size=626&ext=jpg"
  },
  {
    id: "604",
    restaurant_id: "6",
    name: "Kachori Chat",
    price: 85,
    category: "Chat",
    description: "Spicy lentil-stuffed deep fried bread topped with yogurt and chutney",
    image_url: "https://img.freepik.com/free-photo/indian-street-food-maharaj-chat_57665-13059.jpg?size=626&ext=jpg"
  },
  
  // Restaurant 7 - Biryani House
  {
    id: "701",
    restaurant_id: "7",
    name: "Hyderabadi Biryani",
    price: 350,
    category: "Main Course",
    description: "Aromatic basmati rice layered with marinated meat and cooked in dum style",
    image_url: "https://img.freepik.com/free-photo/delicious-traditional-indian-food-arrangement_23-2148749610.jpg?size=626&ext=jpg"
  },
  {
    id: "702",
    restaurant_id: "7",
    name: "Veg Biryani",
    price: 280,
    category: "Main Course",
    description: "Fragrant rice cooked with mixed vegetables and aromatic spices",
    image_url: "https://img.freepik.com/free-photo/traditional-indian-soup-lentils-indian-dhal-spicy-curry-bowl-spices-herbs-rustic-black-wooden-table_2829-18717.jpg?size=626&ext=jpg"
  },
  {
    id: "703",
    restaurant_id: "7",
    name: "Raita",
    price: 60,
    category: "Sides",
    description: "Yogurt mixed with cucumber and spices",
    image_url: "https://img.freepik.com/free-photo/cucumber-raita-is-indian-condiment-based-yogurt-popular-all-over-world-made-with-yogurt-grated-cucumber-herbs_466689-75527.jpg?size=626&ext=jpg"
  },
  {
    id: "704",
    restaurant_id: "7",
    name: "Chicken 65 Biryani",
    price: 380,
    category: "Main Course",
    description: "Spicy fried chicken pieces served with flavored biryani rice",
    image_url: "https://img.freepik.com/free-photo/indian-chicken-biryani-served-terracotta-bowl-with-yogurt-white-background-selective-focus_466689-72554.jpg?size=626&ext=jpg"
  },
  
  // Restaurant 8 - Sweet Memories
  {
    id: "801",
    restaurant_id: "8",
    name: "Gulab Jamun",
    price: 120,
    category: "Dessert",
    description: "Deep-fried milk solid balls soaked in sugar syrup",
    image_url: "https://img.freepik.com/free-photo/gulab-jamun-sweet-food-dessert_96696-323.jpg?size=626&ext=jpg"
  },
  {
    id: "802",
    restaurant_id: "8",
    name: "Rasgulla",
    price: 100,
    category: "Dessert",
    description: "Spongy cheese balls soaked in light sugar syrup",
    image_url: "https://img.freepik.com/premium-photo/bengali-sweet-food-rasgulla-served-bowl-clay-black-background_136354-4316.jpg?size=626&ext=jpg"
  },
  {
    id: "803",
    restaurant_id: "8",
    name: "Jalebi",
    price: 80,
    category: "Dessert",
    description: "Crispy pretzel-shaped sweets soaked in sugar syrup",
    image_url: "https://img.freepik.com/free-photo/jalebi-also-known-jilapi-zalabia-zalebi-zulbia-indian-sweet_466689-76741.jpg?size=626&ext=jpg"
  },
  {
    id: "804",
    restaurant_id: "8",
    name: "Kaju Katli",
    price: 150,
    category: "Dessert",
    description: "Diamond-shaped cashew fudge",
    image_url: "https://img.freepik.com/free-photo/delicious-arabic-sweet-arrangement_23-2148749608.jpg?size=626&ext=jpg"
  },
  {
    id: "805",
    restaurant_id: "8",
    name: "Mysore Pak",
    price: 120,
    category: "Dessert",
    description: "Traditional Bangalore sweet made with gram flour, ghee and sugar",
    image_url: "https://img.freepik.com/free-photo/traditional-indian-dessert-burfi-chakki-milk-cake-white-plate_114579-2326.jpg?size=626&ext=jpg"
  }
];

export const sampleUsers: User[] = [
  {
    id: "u1",
    name: "Amit Kumar",
    phone: "9876543210",
    email: "amit@example.com",
    created_at: "2023-01-15T10:30:00Z"
  },
  {
    id: "u2",
    name: "Priya Sharma",
    phone: "8765432109",
    email: "priya@example.com",
    created_at: "2023-02-20T14:45:00Z"
  }
];

export const sampleOrders: Order[] = [
  {
    id: "o1",
    restaurant_id: "1",
    user_id: "u1",
    order_date: "2023-05-12T18:30:00Z",
    status: "delivered",
    delivery_address: "123 Koramangala, Bangalore",
    special_instructions: "Please add extra chutney",
    total_amount: 520
  },
  {
    id: "o2",
    restaurant_id: "2",
    user_id: "u1",
    order_date: "2023-05-15T13:15:00Z",
    status: "confirmed",
    delivery_address: "123 Indiranagar, Bangalore",
    total_amount: 350
  }
];
