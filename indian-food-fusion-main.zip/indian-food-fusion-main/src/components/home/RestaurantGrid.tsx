
import { useQuery } from "@tanstack/react-query";
import { restaurantService } from "@/services/api";
import RestaurantCard from "./RestaurantCard";
import { Skeleton } from "@/components/ui/skeleton";

interface RestaurantGridProps {
  title: string;
  filter?: string;
}

const RestaurantGrid = ({ title, filter }: RestaurantGridProps) => {
  // Query restaurants with optional filter by cuisine type
  const { 
    data: restaurants, 
    isLoading, 
    error 
  } = useQuery({
    queryKey: ['restaurants', filter],
    queryFn: () => filter ? 
      restaurantService.getRestaurantsByCuisine(filter) : 
      restaurantService.getAllRestaurants()
  });

  if (error) {
    return (
      <div className="text-center py-10">
        <p className="text-red-500">Failed to load restaurants. Please try again later.</p>
      </div>
    );
  }

  return (
    <section>
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="rounded-lg overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <div className="p-4 space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-5/6" />
                <div className="flex justify-between pt-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <>
          {restaurants && restaurants.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {restaurants.map((restaurant) => (
                <RestaurantCard key={restaurant.id} restaurant={restaurant} />
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-gray-500">No restaurants found. Please try a different filter.</p>
            </div>
          )}
        </>
      )}
    </section>
  );
};

export default RestaurantGrid;
