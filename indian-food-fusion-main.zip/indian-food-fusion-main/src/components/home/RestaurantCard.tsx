
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Restaurant } from "@/types";
import { Star, Clock, Badge } from "lucide-react";

interface RestaurantCardProps {
  restaurant: Restaurant;
}

const RestaurantCard = ({ restaurant }: RestaurantCardProps) => {
  return (
    <Link to={`/restaurant/${restaurant.id}`}>
      <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
        <div className="relative h-48">
          <img
            src={restaurant.image_url || "https://img.freepik.com/free-photo/flat-lay-batch-cooking-composition_23-2148765597.jpg"}
            alt={restaurant.name}
            className="w-full h-full object-cover"
          />
          {restaurant.cuisine_type && (
            <div className="absolute top-3 left-3">
              <span className="bg-white px-3 py-1 rounded-full text-xs font-medium shadow-md">
                {restaurant.cuisine_type}
              </span>
            </div>
          )}
        </div>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-bold text-lg line-clamp-1">{restaurant.name}</h3>
            <div className="flex items-center gap-1 bg-green-50 px-2 py-1 rounded text-sm">
              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
              <span className="font-medium">{restaurant.rating}</span>
            </div>
          </div>
          <p className="text-gray-600 mb-3 text-sm line-clamp-1">{restaurant.address}</p>
          <div className="flex justify-between items-center">
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="h-3 w-3 mr-1" />
              <span>{restaurant.delivery_time || '30-45 min'}</span>
            </div>
            {restaurant.min_order !== null && (
              <div className="text-sm text-gray-500">
                Min: ₹{restaurant.min_order}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default RestaurantCard;
