
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Search } from "lucide-react";

const Hero = () => {
  const [location, setLocation] = useState("Bangalore, India");
  
  return (
    <div className="relative bg-gradient-to-r from-red-600 to-red-800 text-white pt-16 pb-32 overflow-hidden">
      {/* Abstract shapes in background */}
      <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-white/10 blur-2xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 rounded-full bg-white/5 blur-3xl -translate-x-1/2 translate-y-1/2"></div>
      <div className="absolute top-1/3 right-1/4 w-32 h-32 rounded-full bg-white/10 blur-xl"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Delicious Food, <br />
            <span className="text-yellow-300">Delivered to Your Doorstep</span>
          </h1>
          <p className="text-lg md:text-xl opacity-90 mb-8">
            Order from a wide selection of your favorite restaurants across Bangalore.
            Enjoy authentic South Indian cuisine and more with fast delivery!
          </p>
          
          <div className="flex items-center justify-center space-x-2 mb-8">
            <MapPin size={20} className="text-yellow-300" />
            <span>Delivering to: {location}</span>
            <Button variant="link" className="text-yellow-300 p-0 underline">Change</Button>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 max-w-xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                className="bg-white pl-10 h-12 text-black"
                placeholder="Search for restaurants, cuisines..."
              />
            </div>
            <Button className="h-12 px-8 bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
              Find Food
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
