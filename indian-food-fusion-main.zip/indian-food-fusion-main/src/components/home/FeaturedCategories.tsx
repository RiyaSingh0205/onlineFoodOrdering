
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Category {
  id: string;
  name: string;
  image: string;
}

const categories: Category[] = [
  {
    id: "1",
    name: "North Indian",
    image: "https://img.freepik.com/free-photo/top-view-indian-food-with-copy-space_23-2148747715.jpg?size=626&ext=jpg"
  },
  {
    id: "2",
    name: "South Indian",
    image: "https://img.freepik.com/free-photo/indian-dosa-with-variety-chutney-sauces_555764-798.jpg?size=626&ext=jpg"
  },
  {
    id: "3",
    name: "Chinese",
    image: "https://img.freepik.com/free-photo/vertical-shot-traditional-indian-meal-with-chicken-spices_181624-32243.jpg?size=626&ext=jpg"
  },
  {
    id: "4",
    name: "Street Food",
    image: "https://img.freepik.com/free-photo/pani-puri-also-known-as-golgappa-chat-item-served-terracotta-plate-selective-focus_466689-73958.jpg?size=626&ext=jpg"
  },
  {
    id: "5",
    name: "Biryani",
    image: "https://img.freepik.com/free-photo/delicious-indian-food-tray_23-2149409103.jpg?size=626&ext=jpg"
  },
  {
    id: "6",
    name: "Sweets",
    image: "https://img.freepik.com/free-photo/indian-sweet-food-gulab-jamun-served-round-ceramic-bowl_466689-71859.jpg?size=626&ext=jpg"
  },
  {
    id: "7",
    name: "Thali",
    image: "https://img.freepik.com/free-photo/flat-lay-pakistani-food-arrangement_23-2148825110.jpg?size=626&ext=jpg"
  },
  {
    id: "8",
    name: "Rolls",
    image: "https://img.freepik.com/free-photo/side-view-shawarma-with-fried-potatoes-board-cookware_176474-3215.jpg?size=626&ext=jpg"
  }
];

interface FeaturedCategoriesProps {
  onSelectCategory: (category: string) => void;
  selectedCategory: string;
}

const FeaturedCategories = ({ 
  onSelectCategory,
  selectedCategory 
}: FeaturedCategoriesProps) => {
  return (
    <div className="py-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Food Categories</h2>
      
      <ScrollArea className="w-full whitespace-nowrap pb-4">
        <div className="flex space-x-4">
          <Button 
            variant={selectedCategory === "" ? "default" : "outline"}
            onClick={() => onSelectCategory("")}
            className={selectedCategory === "" ? "bg-foodie-600 hover:bg-foodie-700" : ""}
          >
            All
          </Button>
          
          {categories.map((category) => (
            <div key={category.id} className="inline-block">
              <Button 
                variant={selectedCategory === category.name ? "default" : "outline"}
                onClick={() => onSelectCategory(category.name)}
                className={`flex flex-col h-auto items-center justify-center gap-2 py-2 px-3 ${
                  selectedCategory === category.name ? "bg-foodie-600 hover:bg-foodie-700" : ""
                }`}
              >
                <div className="w-12 h-12 rounded-full overflow-hidden">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="text-xs font-medium">{category.name}</span>
              </Button>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default FeaturedCategories;
