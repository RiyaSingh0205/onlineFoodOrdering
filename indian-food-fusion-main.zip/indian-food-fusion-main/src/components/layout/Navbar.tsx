import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle,
  SheetFooter,
  SheetClose,
  SheetTrigger 
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Menu, ShoppingBag, Plus, Minus, User, LogOut } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, signOut } = useAuth();
  const { cart, updateQuantity, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();
  
  const getUserInitials = () => {
    if (!user) return 'G';
    const name = user.user_metadata?.name || user.email || '';
    return name.charAt(0).toUpperCase();
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const handleCheckout = () => {
    if (!user) {
      navigate('/login');
    } else {
      // Navigate to checkout page when implemented
      navigate('/checkout');
    }
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <img 
              src="https://img.icons8.com/?size=48&id=5PEYYGIb7J3E&format=png" 
              alt="OrderMate Logo" 
              className="w-8 h-8"
            />
            <span className="font-bold text-xl text-foodie-600">OrderMate</span>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link to="/" className="text-gray-700 hover:text-foodie-600">Home</Link>
            <Link to="/restaurants" className="text-gray-700 hover:text-foodie-600">Restaurants</Link>
            <Link to="/offers" className="text-gray-700 hover:text-foodie-600">Offers</Link>
            <Link to="/contact" className="text-gray-700 hover:text-foodie-600">Contact</Link>
          </nav>
          
          {/* Right side items */}
          <div className="flex items-center gap-4">
            {/* Cart */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="relative">
                  <ShoppingBag className="h-5 w-5" />
                  {cart.items.length > 0 && (
                    <span className="absolute -top-2 -right-2 bg-foodie-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {cart.items.length}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Your Cart</SheetTitle>
                </SheetHeader>
                <div className="py-4">
                  {cart.items.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-8">
                      <ShoppingBag className="h-12 w-12 text-gray-300 mb-2" />
                      <p className="text-gray-500">Your cart is empty</p>
                      <Button variant="link" asChild>
                        <Link to="/">Browse Restaurants</Link>
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-4 mt-4 max-h-[calc(100vh-200px)] overflow-y-auto">
                        {cart.items.map((cartItem) => (
                          <div key={cartItem.item.id} className="border-b pb-4">
                            <div className="flex justify-between">
                              <div>
                                <h4 className="font-medium">{cartItem.item.name}</h4>
                                <p className="text-sm text-gray-500">₹{cartItem.item.price.toFixed(2)}</p>
                              </div>
                              <div className="flex items-center">
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  className="h-7 w-7 rounded-full"
                                  onClick={() => updateQuantity(cartItem.item.id, cartItem.quantity - 1)}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="w-8 text-center">{cartItem.quantity}</span>
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  className="h-7 w-7 rounded-full"
                                  onClick={() => updateQuantity(cartItem.item.id, cartItem.quantity + 1)}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="flex justify-between items-center mt-2">
                              <span className="text-sm">₹{cartItem.total.toFixed(2)}</span>
                              <Button 
                                variant="ghost" 
                                className="h-auto p-0 text-sm text-red-600 hover:text-red-800 hover:bg-transparent"
                                onClick={() => removeFromCart(cartItem.item.id)}
                              >
                                Remove
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="border-t pt-4 mt-6 space-y-4">
                        <div className="flex justify-between font-medium">
                          <span>Total</span>
                          <span>₹{cart.total.toFixed(2)}</span>
                        </div>
                        <SheetFooter className="sm:space-x-0 gap-3 sm:block">
                          <Button 
                            className="w-full bg-foodie-600 hover:bg-foodie-700" 
                            onClick={handleCheckout}
                          >
                            Checkout
                          </Button>
                          <Button 
                            variant="outline" 
                            className="w-full mt-2" 
                            onClick={clearCart}
                          >
                            Clear Cart
                          </Button>
                        </SheetFooter>
                      </div>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>
            
            {/* User Menu */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Avatar className="h-9 w-9 border-2 border-foodie-100">
                      <AvatarFallback className="bg-foodie-100 text-foodie-700">
                        {getUserInitials()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="p-2">
                    <p className="text-sm font-medium">{user.user_metadata?.name || user.email}</p>
                    <p className="text-xs text-gray-500 truncate">{user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/orders" className="cursor-pointer">
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      <span>My Orders</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sign out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button asChild className="bg-foodie-600 hover:bg-foodie-700">
                <Link to="/login">Login</Link>
              </Button>
            )}
            
            {/* Mobile menu button */}
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
        
        {/* Mobile navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden pt-4 pb-2 border-t mt-3 space-y-2">
            <Link 
              to="/" 
              className="block py-2 text-gray-700 hover:text-foodie-600"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/restaurants" 
              className="block py-2 text-gray-700 hover:text-foodie-600"
              onClick={() => setMobileMenuOpen(false)}
            >
              Restaurants
            </Link>
            <Link 
              to="/offers" 
              className="block py-2 text-gray-700 hover:text-foodie-600"
              onClick={() => setMobileMenuOpen(false)}
            >
              Offers
            </Link>
            <Link 
              to="/contact" 
              className="block py-2 text-gray-700 hover:text-foodie-600"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Navbar;
