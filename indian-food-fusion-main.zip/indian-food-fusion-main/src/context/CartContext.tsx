
import { createContext, useState, useContext, ReactNode, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { CartItem, MenuItem, Cart } from "@/types";

type CartContextType = {
  cart: Cart;
  addToCart: (item: MenuItem, quantity: number) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  isItemInCart: (itemId: string) => boolean;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = "foodhub-cart";

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<Cart>({
    items: [],
    restaurant_id: null,
    total: 0
  });
  const { toast } = useToast();

  // Load cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem(CART_STORAGE_KEY);
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (error) {
        console.error("Failed to parse cart data:", error);
        localStorage.removeItem(CART_STORAGE_KEY);
      }
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  }, [cart]);

  const calculateTotal = (items: CartItem[]): number => {
    return items.reduce((sum, item) => sum + item.total, 0);
  };

  const addToCart = (item: MenuItem, quantity: number) => {
    if (quantity <= 0) return;

    setCart(prevCart => {
      // If this is the first item, set the restaurant_id
      const restaurantId = prevCart.restaurant_id || item.restaurant_id;
      
      // If trying to add item from a different restaurant
      if (prevCart.restaurant_id && prevCart.restaurant_id !== item.restaurant_id) {
        toast({
          title: "Can't mix restaurants",
          description: "Your cart already has items from a different restaurant. Clear your cart first.",
          variant: "destructive"
        });
        return prevCart;
      }

      // Check if item already exists
      const existingItemIndex = prevCart.items.findIndex(cartItem => cartItem.item.id === item.id);
      
      let newItems: CartItem[];
      
      if (existingItemIndex >= 0) {
        // Update existing item
        newItems = [...prevCart.items];
        const newQuantity = newItems[existingItemIndex].quantity + quantity;
        newItems[existingItemIndex] = {
          ...newItems[existingItemIndex],
          quantity: newQuantity,
          total: item.price * newQuantity
        };
      } else {
        // Add new item
        newItems = [
          ...prevCart.items,
          {
            item,
            quantity,
            total: item.price * quantity
          }
        ];
      }
      
      const newTotal = calculateTotal(newItems);
      
      toast({
        title: "Added to cart",
        description: `${quantity} x ${item.name} added to your cart.`,
      });
      
      return {
        items: newItems,
        restaurant_id: restaurantId,
        total: newTotal
      };
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prevCart => {
      const newItems = prevCart.items.filter(item => item.item.id !== itemId);
      const newTotal = calculateTotal(newItems);
      
      // Reset restaurant_id if cart is empty
      const newRestaurantId = newItems.length > 0 ? prevCart.restaurant_id : null;
      
      toast({
        title: "Item removed",
        description: "Item removed from your cart.",
      });
      
      return {
        items: newItems,
        restaurant_id: newRestaurantId,
        total: newTotal
      };
    });
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    
    setCart(prevCart => {
      const newItems = prevCart.items.map(item => {
        if (item.item.id === itemId) {
          return {
            ...item,
            quantity,
            total: item.item.price * quantity
          };
        }
        return item;
      });
      
      const newTotal = calculateTotal(newItems);
      
      return {
        ...prevCart,
        items: newItems,
        total: newTotal
      };
    });
  };

  const clearCart = () => {
    setCart({
      items: [],
      restaurant_id: null,
      total: 0
    });
    
    toast({
      title: "Cart cleared",
      description: "All items have been removed from your cart.",
    });
  };

  const isItemInCart = (itemId: string) => {
    return cart.items.some(item => item.item.id === itemId);
  };

  const value = {
    cart,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    isItemInCart
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
