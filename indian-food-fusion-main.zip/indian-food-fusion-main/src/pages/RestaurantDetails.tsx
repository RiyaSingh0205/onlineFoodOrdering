
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { restaurantService, menuService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/context/CartContext';
import { Restaurant, MenuItem } from '@/types';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Star, Clock, AlertCircle, Plus, Minus, ShoppingBag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

const RestaurantDetails = () => {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const { cart, addToCart, updateQuantity, isItemInCart } = useCart();
  const [itemQuantities, setItemQuantities] = useState<Record<string, number>>({});
  const [categories, setCategories] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  
  const { 
    data: restaurant,
    isLoading: isLoadingRestaurant,
    error: restaurantError 
  } = useQuery({
    queryKey: ['restaurant', id],
    queryFn: () => id ? restaurantService.getRestaurantById(id) : Promise.reject('No restaurant ID'),
  });
  
  const { 
    data: menuItems,
    isLoading: isLoadingMenu,
    error: menuError 
  } = useQuery({
    queryKey: ['menuItems', id],
    queryFn: () => id ? menuService.getMenuItems(id) : Promise.reject('No restaurant ID'),
  });
  
  // Extract unique categories when menu items are loaded
  useEffect(() => {
    if (menuItems) {
      // Extract unique categories
      const uniqueCategories = Array.from(new Set(menuItems.map(item => item.category)));
      setCategories(['all', ...uniqueCategories]);
    }
  }, [menuItems]);
  
  useEffect(() => {
    // Initialize quantities for items in cart
    if (menuItems && cart.items.length > 0) {
      const quantities: Record<string, number> = {};
      
      menuItems.forEach(item => {
        const cartItem = cart.items.find(ci => ci.item.id === item.id);
        if (cartItem) {
          quantities[item.id] = cartItem.quantity;
        }
      });
      
      setItemQuantities(quantities);
    }
  }, [menuItems, cart.items]);
  
  const handleAddToCart = (item: MenuItem) => {
    addToCart(item, 1);
    setItemQuantities(prev => ({
      ...prev,
      [item.id]: (prev[item.id] || 0) + 1
    }));
  };
  
  const handleIncreaseQuantity = (item: MenuItem) => {
    const newQuantity = (itemQuantities[item.id] || 0) + 1;
    updateQuantity(item.id, newQuantity);
    setItemQuantities(prev => ({
      ...prev,
      [item.id]: newQuantity
    }));
  };
  
  const handleDecreaseQuantity = (item: MenuItem) => {
    if (itemQuantities[item.id] > 1) {
      const newQuantity = itemQuantities[item.id] - 1;
      updateQuantity(item.id, newQuantity);
      setItemQuantities(prev => ({
        ...prev,
        [item.id]: newQuantity
      }));
    } else {
      // Remove from cart if quantity is 1
      updateQuantity(item.id, 0);
      setItemQuantities(prev => {
        const newQuantities = { ...prev };
        delete newQuantities[item.id];
        return newQuantities;
      });
    }
  };
  
  const filteredMenuItems = menuItems?.filter(item => 
    activeCategory === 'all' || item.category === activeCategory
  );
  
  if (restaurantError || menuError) {
    return (
      <>
        <Navbar />
        <div className="container mx-auto px-4 py-10 text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
          <p className="mb-6">
            We couldn't load the restaurant details. Please try again later.
          </p>
          <Button asChild>
            <Link to="/">Return to Home</Link>
          </Button>
        </div>
        <Footer />
      </>
    );
  }
  
  return (
    <>
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        {/* Restaurant Header */}
        {isLoadingRestaurant ? (
          <div className="mb-8">
            <Skeleton className="h-[200px] w-full mb-4 rounded-xl" />
            <Skeleton className="h-8 w-1/3 mb-2" />
            <Skeleton className="h-6 w-2/3 mb-6" />
            <div className="flex gap-4">
              <Skeleton className="h-6 w-24" />
              <Skeleton className="h-6 w-24" />
            </div>
          </div>
        ) : restaurant ? (
          <>
            {/* Restaurant Image Banner */}
            <div className="rounded-xl overflow-hidden h-[200px] mb-6">
              <img 
                src={restaurant.image_url || "https://img.freepik.com/free-photo/flat-lay-batch-cooking-composition_23-2148765597.jpg"} 
                alt={restaurant.name} 
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Restaurant Info */}
            <div className="mb-8">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-3xl font-bold mb-2">{restaurant.name}</h1>
                  <p className="text-gray-600 mb-3">{restaurant.address}</p>
                  <div className="flex flex-wrap gap-3 mb-4">
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      {restaurant.rating} Rating
                    </Badge>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {restaurant.delivery_time || '30-45 min'}
                    </Badge>
                    <Badge variant="outline">
                      {restaurant.cuisine_type || 'Various Cuisine'}
                    </Badge>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Minimum order</p>
                  <p className="text-lg font-bold">₹{restaurant.min_order || 0}</p>
                </div>
              </div>
            </div>
          </>
        ) : null}
        
        {/* Menu Tabs */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Menu</h2>
          <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory}>
            <TabsList className="mb-6 flex flex-nowrap overflow-x-auto pb-2 scrollbar-hide">
              {categories.map(category => (
                <TabsTrigger key={category} value={category} className="capitalize">
                  {category}
                </TabsTrigger>
              ))}
            </TabsList>
            
            <TabsContent value={activeCategory}>
              {isLoadingMenu ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3, 4, 5, 6].map(i => (
                    <Card key={i}>
                      <CardContent className="p-0">
                        <Skeleton className="h-[120px] w-full rounded-t-lg" />
                        <div className="p-4">
                          <Skeleton className="h-6 w-3/4 mb-2" />
                          <Skeleton className="h-4 w-5/6 mb-4" />
                          <div className="flex justify-between">
                            <Skeleton className="h-5 w-16" />
                            <Skeleton className="h-9 w-20" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredMenuItems && filteredMenuItems.length > 0 ? (
                    filteredMenuItems.map(item => (
                      <Card key={item.id} className="overflow-hidden">
                        <CardContent className="p-0">
                          {item.image_url && (
                            <div className="h-[120px] overflow-hidden">
                              <img 
                                src={item.image_url} 
                                alt={item.name} 
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}
                          <div className="p-4">
                            <h3 className="font-semibold text-lg mb-1">{item.name}</h3>
                            <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                              {item.description || `Delicious ${item.name} from ${restaurant?.name || 'this restaurant'}.`}
                            </p>
                            <div className="flex justify-between items-center">
                              <p className="font-medium">₹{item.price.toFixed(2)}</p>
                              
                              {isItemInCart(item.id) ? (
                                <div className="flex items-center gap-3">
                                  <Button 
                                    variant="outline" 
                                    size="icon" 
                                    className="h-8 w-8 rounded-full"
                                    onClick={() => handleDecreaseQuantity(item)}
                                  >
                                    <Minus className="h-3 w-3" />
                                  </Button>
                                  <span className="font-medium">
                                    {itemQuantities[item.id] || 0}
                                  </span>
                                  <Button 
                                    variant="outline" 
                                    size="icon" 
                                    className="h-8 w-8 rounded-full"
                                    onClick={() => handleIncreaseQuantity(item)}
                                  >
                                    <Plus className="h-3 w-3" />
                                  </Button>
                                </div>
                              ) : (
                                <Button 
                                  size="sm" 
                                  className="bg-foodie-600 hover:bg-foodie-700"
                                  onClick={() => handleAddToCart(item)}
                                >
                                  <ShoppingBag className="h-4 w-4 mr-2" />
                                  Add
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="col-span-full text-center py-10">
                      <p className="text-gray-500">No menu items found in this category.</p>
                    </div>
                  )}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default RestaurantDetails;
