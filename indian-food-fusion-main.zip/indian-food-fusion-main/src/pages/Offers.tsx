
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Clock, Tag, Percent, Info } from "lucide-react";

// Sample offers data
const offers = [
  {
    id: "1",
    code: "WELCOME50",
    title: "50% Off On Your First Order",
    description: "Get 50% off up to ₹100 on your first order",
    validUntil: "2025-06-30",
    minOrder: 200,
    category: "new",
  },
  {
    id: "2",
    code: "FREEDEL",
    title: "Free Delivery",
    description: "Enjoy free delivery on your food order above ₹300",
    validUntil: "2025-05-31",
    minOrder: 300,
    category: "delivery",
  },
  {
    id: "3",
    code: "WEEKEND20",
    title: "Weekend Special - 20% Off",
    description: "Get 20% off up to ₹150 during weekends",
    validUntil: "2025-06-30",
    minOrder: 400,
    category: "seasonal",
  },
  {
    id: "4",
    code: "LUNCH15",
    title: "Lunch Time Special - 15% Off",
    description: "Get 15% off between 12 PM - 3 PM",
    validUntil: "2025-06-30",
    minOrder: 250,
    category: "special",
  },
  {
    id: "5",
    code: "DINNER25",
    title: "Dinner Time Special - 25% Off",
    description: "Get 25% off between 7 PM - 11 PM on dinner orders",
    validUntil: "2025-06-15",
    minOrder: 500,
    category: "special",
  },
];

const Offers = () => {
  const { toast } = useToast();
  
  const copyCodeToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Code copied!",
      description: `${code} has been copied to your clipboard.`,
    });
  };
  
  const categories = [
    { value: "all", label: "All Offers" },
    { value: "new", label: "New User" },
    { value: "delivery", label: "Delivery" },
    { value: "seasonal", label: "Seasonal" },
    { value: "special", label: "Special" },
  ];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-gradient-to-r from-foodie-600 to-foodie-800 text-white py-16">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Offers & Promotions</h1>
            <p className="text-lg opacity-90">Discover the latest offers and save on your favorite meals</p>
          </div>
        </div>
        
        <div className="container mx-auto px-4 py-8">
          <Tabs defaultValue="all" className="mb-8">
            <TabsList className="mb-8 flex flex-wrap">
              {categories.map((category) => (
                <TabsTrigger key={category.value} value={category.value} className="px-6">
                  {category.label}
                </TabsTrigger>
              ))}
            </TabsList>
            
            <TabsContent value="all" className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {offers.map((offer) => (
                <OfferCard key={offer.id} offer={offer} onCopyCode={copyCodeToClipboard} />
              ))}
            </TabsContent>
            
            {categories.slice(1).map((category) => (
              <TabsContent key={category.value} value={category.value} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {offers
                  .filter((offer) => offer.category === category.value)
                  .map((offer) => (
                    <OfferCard key={offer.id} offer={offer} onCopyCode={copyCodeToClipboard} />
                  ))}
              </TabsContent>
            ))}
          </Tabs>
          
          <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg flex items-start mt-8">
            <Info className="text-yellow-500 mr-4 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-yellow-800 mb-1">How to use offers</h3>
              <p className="text-yellow-700 text-sm">
                Copy the promo code and apply it at checkout. Offers cannot be combined and are subject to terms and conditions.
                For testing purposes, all payments are simulated and no actual transactions will occur.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

interface OfferCardProps {
  offer: {
    id: string;
    code: string;
    title: string;
    description: string;
    validUntil: string;
    minOrder: number;
    category: string;
  };
  onCopyCode: (code: string) => void;
}

const OfferCard = ({ offer, onCopyCode }: OfferCardProps) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  return (
    <Card className="overflow-hidden border-2">
      <div className="bg-gradient-to-r from-foodie-50 to-foodie-100 p-2 flex justify-between items-center">
        <div className="flex items-center">
          <Tag className="text-foodie-700 mr-2" />
          <span className="font-medium">Promo Code:</span>
        </div>
        <span className="font-bold text-foodie-800">{offer.code}</span>
      </div>
      
      <CardHeader>
        <CardTitle>{offer.title}</CardTitle>
        <CardDescription>{offer.description}</CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="flex flex-col space-y-2 text-sm">
          <div className="flex items-center text-gray-600">
            <Clock className="h-4 w-4 mr-2" />
            <span>Valid until {formatDate(offer.validUntil)}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Percent className="h-4 w-4 mr-2" />
            <span>Min. order: ₹{offer.minOrder}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          onClick={() => onCopyCode(offer.code)} 
          className="w-full bg-foodie-600 hover:bg-foodie-700"
        >
          Copy Code
        </Button>
      </CardFooter>
    </Card>
  );
};

export default Offers;
