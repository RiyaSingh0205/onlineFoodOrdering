
import { useState } from "react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/home/Hero";
import RestaurantGrid from "@/components/home/RestaurantGrid";
import FeaturedCategories from "@/components/home/FeaturedCategories";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const Index = () => {
  const [selectedCategory, setSelectedCategory] = useState("");
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        
        <div className="container mx-auto px-4 py-10 -mt-16">
          <div className="bg-white rounded-xl shadow-lg p-6 mb-10">
            <FeaturedCategories 
              onSelectCategory={setSelectedCategory}
              selectedCategory={selectedCategory}
            />
          </div>
          
          <div className="space-y-16">
            <RestaurantGrid 
              title={selectedCategory ? `${selectedCategory} Restaurants` : "Popular Restaurants in Bangalore"}
              filter={selectedCategory}
            />
            
            <div className="text-center">
              <Link to="/restaurants">
                <Button className="bg-foodie-600 hover:bg-foodie-700">
                  See All Restaurants <ArrowRight size={16} className="ml-2" />
                </Button>
              </Link>
            </div>
            
            {/* Additional Sections */}
            <section className="bg-gray-50 rounded-xl p-8">
              <div className="grid md:grid-cols-2 gap-10 items-center">
                <div>
                  <h2 className="text-3xl font-bold mb-4">Download Our App</h2>
                  <p className="text-gray-600 mb-6">
                    Get the best food delivery experience in Bangalore on your smartphone. 
                    Order food on the go, track your delivery in real-time, and enjoy exclusive app-only offers!
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button className="flex items-center justify-center bg-black hover:bg-gray-800 text-white gap-2">
                      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.5227 7.39601V8.92935C17.5227 9.31491 17.2061 9.6315 16.8205 9.6315C16.435 9.6315 16.1183 9.31491 16.1183 8.92935V7.39601C16.1183 7.01045 16.435 6.69386 16.8205 6.69386C17.2061 6.69386 17.5227 7.01045 17.5227 7.39601Z" fill="currentColor"/>
                        <path fillRule="evenodd" clipRule="evenodd" d="M15.4113 3C14.8157 3 14.2784 3.21166 13.9203 3.57814L7.2213 10.3857L7.22522 10.3901L6.68577 10.9348L6.67238 10.9227C6.41092 11.1513 6.41943 11.5329 6.67238 11.7858L13.9203 19.1493C14.2784 19.5158 14.8157 19.7275 15.4113 19.7275H18.3073C19.5543 19.7275 20.564 18.7089 20.564 17.4513V5.27572C20.564 4.01827 19.5543 3 18.3073 3H15.4113ZM18.7651 17.4513C18.7651 17.7085 18.5602 17.9163 18.3073 17.9163H15.4113C15.2148 17.9163 15.0279 17.8419 14.9015 17.7123L8.36364 11.1071L8.81374 10.6506L10.3873 9.05732C10.3873 9.05732 14.9015 4.49612 14.9015 4.31496C15.0279 4.18562 15.2148 4.11117 15.4113 4.11117H18.3073C18.5602 4.11117 18.7651 4.31833 18.7651 4.57572V17.4513Z" fill="currentColor"/>
                        <path d="M3.43481 11.0225L4.97702 12.6034C5.17371 12.8072 5.17371 13.1203 4.97702 13.3242L3.43481 14.9051C3.23813 15.1089 2.95582 15.1089 2.75914 14.9051C2.56245 14.7013 2.56245 14.3882 2.75914 14.1844L3.93559 12.9638L2.75914 11.7432C2.56245 11.5394 2.56245 11.2263 2.75914 11.0225C2.95582 10.8187 3.23813 10.8187 3.43481 11.0225Z" fill="currentColor"/>
                      </svg>
                      Google Play
                    </Button>
                    <Button className="flex items-center justify-center bg-black hover:bg-gray-800 text-white gap-2">
                      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18.7101 19.5C17.88 20.74 17 22 15.66 22H15.64C14.76 22 14.18 21.61 13.57 21.2C12.95 20.79 12.32 20.37 11.36 20.37C10.4 20.37 9.77 20.79 9.14 21.2C8.53 21.61 7.94 22 7.06 22H7.05C5.71 22 4.82 20.74 3.99 19.5C2.34 17.24 1 13.66 1 10.14C1 5.45 4.18 3.2 7.05 3.2H7.06C7.94 3.2 8.53 3.61 9.14 4.04C9.77 4.44 10.4 4.84 11.36 4.84C12.32 4.84 12.95 4.44 13.57 4.04C14.18 3.61 14.76 3.2 15.64 3.2H15.66C18.53 3.2 21.71 5.45 21.71 10.14C21.71 13.66 20.37 17.24 18.7101 19.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        <path d="M17 0.75V6.75" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        <path d="M7 0.75V6.75" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      App Store
                    </Button>
                  </div>
                </div>
                <div className="flex justify-center">
                  <img 
                    src="https://img.freepik.com/free-vector/realistic-logistic-landing-page-template_52683-79239.jpg" 
                    alt="Mobile App" 
                    className="w-full max-w-sm rounded-xl shadow-lg"
                  />
                </div>
              </div>
            </section>
            
            {/* Testimonials */}
            <section>
              <h2 className="text-3xl font-bold text-center mb-10">What Our Customers in Bangalore Say</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  {
                    name: "Aditya Sharma",
                    role: "Food Enthusiast",
                    quote: "The fastest delivery in Koramangala. My food always arrives hot and fresh. OrderMate has become my go-to app for ordering meals!",
                    image: "https://randomuser.me/api/portraits/men/32.jpg"
                  },
                  {
                    name: "Priya Patel",
                    role: "Working Professional",
                    quote: "The variety of restaurants available in Indiranagar is amazing. I've discovered so many new places through OrderMate that I now love ordering from.",
                    image: "https://randomuser.me/api/portraits/women/44.jpg"
                  },
                  {
                    name: "Rajiv Singh",
                    role: "College Student",
                    quote: "Great discounts on HSR Layout restaurants! The app is super easy to use and the customer service is top-notch. Highly recommended!",
                    image: "https://randomuser.me/api/portraits/men/62.jpg"
                  }
                ].map((testimonial, index) => (
                  <div key={index} className="bg-white border border-gray-100 p-6 rounded-xl shadow-sm">
                    <div className="flex items-center space-x-4 mb-4">
                      <img 
                        src={testimonial.image} 
                        alt={testimonial.name} 
                        className="w-12 h-12 rounded-full"
                      />
                      <div>
                        <h4 className="font-semibold">{testimonial.name}</h4>
                        <p className="text-sm text-gray-500">{testimonial.role}</p>
                      </div>
                    </div>
                    <p className="text-gray-600 italic">"{testimonial.quote}"</p>
                    <div className="flex mt-3 text-yellow-500">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                        </svg>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
