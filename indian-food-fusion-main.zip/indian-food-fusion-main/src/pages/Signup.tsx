
import { SignupForm } from "@/components/auth/SignupForm";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const Signup = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    // Check if user is already logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn === "true") {
      navigate("/");
    }
  }, [navigate]);
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-foodie-50 to-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6 flex items-center gap-1"
          onClick={() => navigate("/")}
        >
          <ArrowLeft size={16} />
          <span>Back to home</span>
        </Button>

        <div className="flex flex-col lg:flex-row gap-8 items-center">
          <div className="lg:w-1/2 flex flex-col items-center lg:items-start">
            <h1 className="text-4xl font-bold text-foodie-800 mb-4">Join FoodHub Today!</h1>
            <p className="text-lg text-gray-600 mb-8 text-center lg:text-left">
              Create an account to discover and order delicious food from the best restaurants in your area. 
              Get exclusive offers and track your deliveries in real-time!
            </p>
            <div className="hidden lg:block w-full max-w-md">
              <img 
                src="https://img.freepik.com/free-vector/restaurant-mural-wallpaper_23-2148703851.jpg" 
                alt="Food delivery illustration" 
                className="rounded-xl shadow-xl"
              />
            </div>
          </div>

          <div className="w-full lg:w-1/2">
            <SignupForm />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
