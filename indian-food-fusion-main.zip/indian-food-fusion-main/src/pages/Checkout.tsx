
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { orderService, paymentService } from '@/services/api';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { CreditCard, BanknoteIcon, Wallet, Info } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

const formSchema = z.object({
  address: z.string().min(5, { message: 'Address must be at least 5 characters.' }),
  instructions: z.string().optional(),
  paymentMethod: z.enum(['cash', 'card', 'upi'], {
    required_error: 'You need to select a payment method.',
  }),
});

const Checkout = () => {
  const { cart, clearCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      address: '',
      instructions: '',
      paymentMethod: 'cash',
    },
  });
  
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to complete your order",
        variant: "destructive"
      });
      navigate('/login');
      return;
    }
    
    if (cart.items.length === 0) {
      toast({
        title: "Empty cart",
        description: "Your cart is empty. Add some items before checkout.",
        variant: "destructive"
      });
      navigate('/');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      toast({
        title: "Test Mode",
        description: "This is a demonstration only. No actual payment will be processed.",
      });
      
      // Create order
      const orderData = {
        restaurant_id: cart.restaurant_id!,
        user_id: user.id,
        status: 'pending',
        delivery_address: values.address,
        special_instructions: values.instructions || null,
        total_amount: cart.total,
        order_date: new Date().toISOString(),
      };
      
      // Prepare order items
      const orderItems = cart.items.map(item => ({
        item_id: item.item.id,
        quantity: item.quantity,
        total: item.total
      }));
      
      const { order } = await orderService.createOrder(orderData, orderItems);
      
      // Create payment record
      await paymentService.createPayment({
        order_id: order.id,
        method: values.paymentMethod,
        amount: cart.total,
        status: values.paymentMethod === 'cash' ? 'pending' : 'completed',
        payment_date: values.paymentMethod === 'cash' ? null : new Date().toISOString()
      });
      
      // Success - clear cart and show confirmation
      clearCart();
      toast({
        title: "Order placed successfully!",
        description: `Your order has been placed. Order ID: ${order.id.slice(0, 8)}...`,
      });
      
      // Navigate to order confirmation page
      navigate(`/`);
    } catch (error) {
      console.error('Error placing order:', error);
      toast({
        title: "Failed to place order",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Redirect if not logged in
  if (!user) {
    navigate('/login');
    return null;
  }
  
  // Redirect if cart is empty
  if (cart.items.length === 0) {
    navigate('/');
    return null;
  }
  
  return (
    <>
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Checkout</h1>
        
        <Alert className="mb-6 bg-blue-50 text-blue-800 border-blue-200">
          <Info className="h-4 w-4 text-blue-500" />
          <AlertDescription>
            This is a demonstration application. No actual payments will be processed.
          </AlertDescription>
        </Alert>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Checkout Form */}
          <div className="col-span-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="bg-white rounded-lg p-6 shadow-sm border">
                  <h2 className="text-xl font-semibold mb-4">Delivery Details</h2>
                  
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Delivery Address</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your full address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="instructions"
                    render={({ field }) => (
                      <FormItem className="mt-4">
                        <FormLabel>Special Instructions (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Any special instructions for delivery or food preparation" 
                            className="resize-none" 
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="bg-white rounded-lg p-6 shadow-sm border">
                  <h2 className="text-xl font-semibold mb-4">Payment Method</h2>
                  
                  <FormField
                    control={form.control}
                    name="paymentMethod"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="grid grid-cols-1 md:grid-cols-3 gap-4"
                          >
                            <FormItem className="flex flex-col items-center space-x-0 space-y-2">
                              <FormControl>
                                <RadioGroupItem value="cash" id="cash" className="peer sr-only" />
                              </FormControl>
                              <label
                                htmlFor="cash"
                                className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 peer-data-[state=checked]:border-foodie-500 [&:has([data-state=checked])]:border-foodie-500 cursor-pointer w-full"
                              >
                                <BanknoteIcon className="h-6 w-6 text-gray-500" />
                                <span className="mt-2 font-medium">Cash on Delivery</span>
                              </label>
                            </FormItem>
                            
                            <FormItem className="flex flex-col items-center space-x-0 space-y-2">
                              <FormControl>
                                <RadioGroupItem value="card" id="card" className="peer sr-only" />
                              </FormControl>
                              <label
                                htmlFor="card"
                                className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 peer-data-[state=checked]:border-foodie-500 [&:has([data-state=checked])]:border-foodie-500 cursor-pointer w-full"
                              >
                                <CreditCard className="h-6 w-6 text-gray-500" />
                                <span className="mt-2 font-medium">Credit/Debit Card</span>
                              </label>
                            </FormItem>
                            
                            <FormItem className="flex flex-col items-center space-x-0 space-y-2">
                              <FormControl>
                                <RadioGroupItem value="upi" id="upi" className="peer sr-only" />
                              </FormControl>
                              <label
                                htmlFor="upi"
                                className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 peer-data-[state=checked]:border-foodie-500 [&:has([data-state=checked])]:border-foodie-500 cursor-pointer w-full"
                              >
                                <Wallet className="h-6 w-6 text-gray-500" />
                                <span className="mt-2 font-medium">UPI</span>
                              </label>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full md:w-auto bg-foodie-600 hover:bg-foodie-700"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Placing Order...' : 'Place Order'}
                </Button>
              </form>
            </Form>
          </div>
          
          {/* Order Summary */}
          <div className="col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {cart.items.map((item) => (
                  <div key={item.item.id} className="flex justify-between">
                    <div>
                      <p className="font-medium">{item.item.name}</p>
                      <p className="text-sm text-gray-500">x{item.quantity}</p>
                    </div>
                    <p className="font-medium">₹{item.total.toFixed(2)}</p>
                  </div>
                ))}
                
                <Separator className="my-4" />
                
                <div className="flex justify-between">
                  <p>Subtotal</p>
                  <p className="font-medium">₹{cart.total.toFixed(2)}</p>
                </div>
                <div className="flex justify-between">
                  <p>Delivery Fee</p>
                  <p className="font-medium">₹40.00</p>
                </div>
                <div className="flex justify-between">
                  <p>Tax</p>
                  <p className="font-medium">₹{(cart.total * 0.05).toFixed(2)}</p>
                </div>
              </CardContent>
              <CardFooter>
                <div className="w-full flex justify-between text-lg font-bold">
                  <p>Total</p>
                  <p>₹{(cart.total + 40 + cart.total * 0.05).toFixed(2)}</p>
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Checkout;
