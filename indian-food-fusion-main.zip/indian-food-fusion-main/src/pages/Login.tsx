
import { LoginForm } from "@/components/auth/LoginForm";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const Login = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    // Check if user is already logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn === "true") {
      navigate("/");
    }
  }, [navigate]);
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-foodie-50 to-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6 flex items-center gap-1"
          onClick={() => navigate("/")}
        >
          <ArrowLeft size={16} />
          <span>Back to home</span>
        </Button>

        <div className="flex flex-col lg:flex-row gap-8 items-center">
          <div className="lg:w-1/2 flex flex-col items-center lg:items-start">
            <h1 className="text-4xl font-bold text-foodie-800 mb-4">Welcome Back!</h1>
            <p className="text-lg text-gray-600 mb-8 text-center lg:text-left">
              Log in to continue ordering your favorite meals from top restaurants.
              Your delicious food is just a few clicks away!
            </p>
            <div className="hidden lg:block w-full max-w-md">
              <img 
                src="https://img.freepik.com/free-vector/indian-food-elements_1284-33619.jpg" 
                alt="Indian food illustration" 
                className="rounded-xl shadow-xl"
              />
            </div>
          </div>

          <div className="w-full lg:w-1/2">
            <LoginForm />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
